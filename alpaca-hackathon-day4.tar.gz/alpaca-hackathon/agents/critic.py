"""
Critic agent: independently reviews a Proposal for risk before it can
reach execution. Uses a DIFFERENT underlying model than the Proposer
(configured via settings.critic_model) so the review isn't just the
same model checking its own work.

The Critic does NOT re-generate a trade idea - it only evaluates the
one it's given, and must ground its verdict in the actual signal data,
not just the Proposer's stated rationale (a Proposer could describe a
weak setup persuasively; the Critic is given the raw signal too so it
can independently judge whether the rationale holds up).
"""

from __future__ import annotations

import json

from agents.llm_client import call_model
from agents.types import CriticReview, Proposal
from config.settings import settings
from signals.engine import FullSignal

SYSTEM_PROMPT = """You are the Critic agent in an automated options trading system.
A Proposer agent has generated a trade proposal. Your job is to independently assess
its risk and soundness - you are the last checkpoint before this trade could reach
either a human reviewer or autonomous execution, depending on system mode.

You are given BOTH the original signal data AND the Proposer's proposal + rationale.
Do not simply trust the Proposer's rationale - check it against the actual signal values.

Evaluate for:
- Does the proposed direction/strategy actually match what the signal data shows?
  (e.g. does a bullish strategy make sense given RSI/MA trend/MACD, or is the Proposer
  cherry-picking one indicator while ignoring conflicting ones?)
- Is the strategy choice appropriate given IV Rank/Percentile? (credit spreads make more
  sense when IV is elevated; buying premium is expensive when IV is already rich)
- Are the strikes/expiry reasonable relative to the underlying price and ATR (a very
  tight strike relative to ATR is a much riskier bet than it might first appear)?
- Does the Proposer's own stated confidence seem justified, inflated, or understated?

You MUST respond with ONLY valid JSON, no other text, in exactly this shape:
{
  "verdict": "approve" or "reject" or "flag",
  "rationale": "2-4 sentence independent assessment grounded in the signal data",
  "risk_score": <float between 0.0 (very safe) and 1.0 (very risky)>,
  "concerns": ["short phrase describing concern 1", "concern 2", ...] or []
}

Use "flag" when the trade isn't clearly bad but has a specific concern worth a human's
attention before proceeding (e.g. borderline confidence, thin conflicting signals).
Use "reject" when the rationale doesn't hold up against the data, or risk is too high.
Use "approve" only when the strategy is well-justified by the signal data.
"""


def _build_user_prompt(signal: FullSignal, proposal: Proposal) -> str:
    return json.dumps({
        "signal": {
            "symbol": signal.symbol,
            "underlying_price": signal.underlying_price,
            "rsi": signal.rsi,
            "ma_trend": signal.ma_trend,
            "macd": signal.macd,
            "macd_signal": signal.macd_signal,
            "macd_histogram": signal.macd_histogram,
            "atr": signal.atr,
            "iv_rank": signal.iv_rank,
            "iv_percentile": signal.iv_percentile,
            "hv_iv_spread": signal.hv_iv_spread,
        },
        "proposal": {
            "strategy_type": proposal.strategy_type.value,
            "legs": [leg.to_dict() for leg in proposal.legs],
            "rationale": proposal.rationale,
            "confidence": proposal.confidence,
        },
    }, indent=2)


def _parse_llm_response(raw: str) -> CriticReview:
    """Parses the Critic's JSON response. Unlike the Proposer, a Critic
    response that fails to parse should NOT silently disappear - that
    would let a bad proposal through by default. We fail closed: an
    unparseable Critic response is treated as a 'reject' with a note
    explaining why, rather than allowing the proposal through."""
    cleaned = raw.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```")[1]
        if cleaned.startswith("json"):
            cleaned = cleaned[4:]
    cleaned = cleaned.strip()

    try:
        data = json.loads(cleaned)
        verdict = data.get("verdict")
        if verdict not in ("approve", "reject", "flag"):
            raise ValueError("invalid verdict value")

        risk_score = max(0.0, min(1.0, float(data.get("risk_score", 1.0))))

        return CriticReview(
            verdict=verdict,
            rationale=data.get("rationale", ""),
            risk_score=risk_score,
            concerns=data.get("concerns", []),
        )
    except (json.JSONDecodeError, ValueError, TypeError) as e:
        # Fail closed: malformed Critic output blocks the trade rather than
        # letting it through silently.
        return CriticReview(
            verdict="reject",
            rationale=f"Critic response could not be parsed/validated ({e}); "
                      "failing closed and rejecting this proposal.",
            risk_score=1.0,
            concerns=["critic_output_malformed"],
        )


def review_proposal(signal: FullSignal, proposal: Proposal) -> CriticReview:
    """Main entrypoint: independently reviews a Proposal against its
    originating signal, using a different model than the Proposer."""
    user_prompt = _build_user_prompt(signal, proposal)
    raw_response = call_model(
        model=settings.critic_model,
        system_prompt=SYSTEM_PROMPT,
        user_prompt=user_prompt,
        temperature=0.2,  # slightly lower temp - critic should be more consistent
    )
    return _parse_llm_response(raw_response)


if __name__ == "__main__":
    # Smoke test: `python -m agents.critic`
    # Requires AIML_API_KEY, Alpaca + Supabase credentials (via signal + proposer).
    from agents.proposer import generate_proposal
    from signals.engine import build_signal

    signal = build_signal("AAPL")
    proposal = generate_proposal(signal)

    if proposal is None:
        print("Proposer declined - nothing for the Critic to review. "
              "Try a different symbol or wait for a clearer signal.")
    else:
        print(f"Proposal to review: {proposal.strategy_type.value} on {proposal.symbol} "
              f"(confidence {proposal.confidence})")
        review = review_proposal(signal, proposal)
        print(f"\nCritic verdict: {review.verdict}")
        print(f"Risk score: {review.risk_score}")
        print(f"Rationale: {review.rationale}")
        print(f"Concerns: {review.concerns}")
