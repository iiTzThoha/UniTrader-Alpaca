"""
Day 5 — Dashboard.

Streamlit app that surfaces the four core tables (proposals, wishlist,
trades, circuit_breaker_events) and gives a human a real review action
for proposals stuck in 'pending_review'/'flag' status — the gap that
Day 4's auto-wishlist-routing was always a stopgap for.

Run with:
    streamlit run dashboard/app.py

This must be run from the project root (or with the project root on
PYTHONPATH) so the `core`, `agents`, `execution`, `persistence` imports
resolve the same way the rest of the codebase does.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Allow running as `streamlit run dashboard/app.py` from repo root without
# needing PYTHONPATH set manually.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from datetime import datetime, timezone

import pandas as pd
import streamlit as st

from config.settings import settings
from core.circuit_breaker import check_pre_scan, clear_manual_halt, trigger_manual_halt
from execution.executor import execute_proposal
from persistence.supabase_client import get_client

st.set_page_config(page_title="Alpaca Options Bot", layout="wide", page_icon="📈")


# ---------------------------------------------------------------------
# Data loaders (cached briefly so repeated widget interactions on the
# same page load don't re-hit Supabase for every button render)
# ---------------------------------------------------------------------

@st.cache_data(ttl=15)
def load_table(name: str, order_col: str = "created_at", limit: int = 200) -> pd.DataFrame:
    client = get_client()
    result = (
        client.table(name)
        .select("*")
        .order(order_col, desc=True)
        .limit(limit)
        .execute()
    )
    return pd.DataFrame(result.data)


def get_account_snapshot():
    """Live Alpaca account numbers for the top-of-page header. Not cached —
    this is cheap and should always be fresh."""
    from core.alpaca_client import get_trading_client

    client = get_trading_client()
    account = client.get_account()
    positions = client.get_all_positions()
    return account, positions


def refresh_all():
    load_table.clear()
    st.rerun()


# ---------------------------------------------------------------------
# Header: account snapshot + circuit breaker status + kill switch
# ---------------------------------------------------------------------

st.title("📈 Options Trading Agent — Live Dashboard")

try:
    account, positions = get_account_snapshot()
    equity = float(account.equity)
    last_equity = float(account.last_equity)
    daily_pnl = equity - last_equity
    daily_pnl_pct = (daily_pnl / last_equity * 100) if last_equity else 0.0

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Account Equity", f"${equity:,.2f}", f"{daily_pnl:+,.2f} ({daily_pnl_pct:+.2f}%)")
    col2.metric("Open Positions", len(positions))
    col3.metric("Execution Mode", settings.execution_mode.value.upper())
    col4.metric("Active Mode", settings.active_mode)
except Exception as e:
    st.error(f"Could not fetch live Alpaca account data: {e}")

st.divider()

# Circuit breaker status row
cb_col1, cb_col2, cb_col3 = st.columns([2, 1, 1])

with cb_col1:
    st.subheader("Circuit Breaker")
    if st.button("Run check_pre_scan() now"):
        with st.spinner("Checking circuit breaker against live account state..."):
            result = check_pre_scan()
        if result.tripped:
            st.error(f"🔴 TRIPPED — reasons: {[r.value for r in result.reasons]}")
        else:
            st.success("🟢 Not tripped — safe to scan/trade")

with cb_col2:
    st.write("")
    st.write("")
    if st.button("🛑 Trigger manual halt", type="secondary"):
        trigger_manual_halt(notes="Triggered from dashboard")
        st.warning("Manual halt triggered. Bot will not scan or execute until cleared.")
        refresh_all()

with cb_col3:
    st.write("")
    st.write("")
    if st.button("✅ Clear halt", type="secondary"):
        clear_manual_halt(notes="Cleared from dashboard")
        st.success("Circuit breaker cleared.")
        refresh_all()

st.divider()


# ---------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------

tab_review, tab_proposals, tab_wishlist, tab_trades, tab_breaker_log = st.tabs(
    ["🔍 Review Queue", "📋 All Proposals", "⭐ Wishlist", "💰 Trades", "🚨 Breaker Log"]
)


# ---------------------------------------------------------------------
# Tab 1: Review Queue — the actual gap this dashboard exists to close.
# Shows proposals with status pending_review, plus flag-verdict rows,
# with real Approve / Reject actions.
# ---------------------------------------------------------------------

with tab_review:
    st.caption(
        "Proposals awaiting a human decision. Approving here sets status to "
        "'approved' and immediately calls execute_proposal() — this places a "
        "REAL paper order via Alpaca."
    )

    proposals_df = load_table("proposals", limit=300)

    if proposals_df.empty:
        st.info("No proposals found yet.")
    else:
        review_df = proposals_df[
            proposals_df["status"].isin(["pending_review", "wishlisted"])
            | (proposals_df["critic_verdict"] == "flag")
        ].copy()
        # Don't show ones already executed/rejected even if verdict was flag
        review_df = review_df[~review_df["status"].isin(["executed", "rejected", "expired"])]

        if review_df.empty:
            st.success("Review queue is empty — nothing waiting on a human decision.")
        else:
            st.write(f"**{len(review_df)} proposal(s)** waiting for review")

            for _, row in review_df.iterrows():
                verdict = row.get("critic_verdict") or "—"
                risk = row.get("critic_risk_score")
                risk_str = f"{risk:.2f}" if risk is not None else "—"

                with st.expander(
                    f"{row['symbol']} — {row['strategy_type']} — verdict: {verdict} "
                    f"(risk {risk_str}) — status: {row['status']}"
                ):
                    left, right = st.columns([2, 1])
                    with left:
                        st.markdown(f"**Proposer rationale:** {row.get('proposer_rationale') or '—'}")
                        st.markdown(f"**Proposer confidence:** {row.get('proposer_confidence')}")
                        st.markdown(f"**Critic rationale:** {row.get('critic_rationale') or '—'}")
                        st.markdown(f"**Legs:**")
                        st.json(row.get("proposed_contracts") or [])
                    with right:
                        st.markdown(f"**Created:** {row.get('created_at')}")
                        st.markdown(f"**Timeframe:** {row.get('timeframe')}")
                        st.markdown(f"**Execution mode at creation:** {row.get('execution_mode_at_creation')}")

                    btn_col1, btn_col2 = st.columns(2)

                    with btn_col1:
                        if st.button(f"✅ Approve & Execute", key=f"approve_{row['id']}"):
                            client = get_client()
                            client.table("proposals").update(
                                {
                                    "status": "approved",
                                    "reviewed_at": datetime.now(timezone.utc).isoformat(),
                                    "reviewed_by": "human",
                                }
                            ).eq("id", row["id"]).execute()
                            client.table("reviews_rejections").insert(
                                {
                                    "proposal_id": row["id"],
                                    "reviewer_type": "human",
                                    "decision": "approve",
                                    "reason": "Approved via dashboard review queue",
                                }
                            ).execute()

                            # Re-fetch the row now that status=approved, so
                            # execute_proposal's status guard passes.
                            fresh = (
                                client.table("proposals")
                                .select("*")
                                .eq("id", row["id"])
                                .single()
                                .execute()
                            )
                            with st.spinner("Submitting order(s) to Alpaca..."):
                                exec_result = execute_proposal(fresh.data)

                            if exec_result.success:
                                st.success(exec_result.message)
                            else:
                                st.error(exec_result.message)
                            refresh_all()

                    with btn_col2:
                        reject_reason = st.text_input(
                            "Rejection reason (optional)", key=f"reason_{row['id']}"
                        )
                        if st.button(f"❌ Reject", key=f"reject_{row['id']}"):
                            client = get_client()
                            client.table("proposals").update(
                                {
                                    "status": "rejected",
                                    "reviewed_at": datetime.now(timezone.utc).isoformat(),
                                    "reviewed_by": "human",
                                }
                            ).eq("id", row["id"]).execute()
                            client.table("reviews_rejections").insert(
                                {
                                    "proposal_id": row["id"],
                                    "reviewer_type": "human",
                                    "decision": "reject",
                                    "reason": reject_reason or "Rejected via dashboard review queue",
                                    "rejection_category": "other",
                                }
                            ).execute()
                            st.warning("Proposal rejected.")
                            refresh_all()


# ---------------------------------------------------------------------
# Tab 2: All proposals (read-only browse/filter)
# ---------------------------------------------------------------------

with tab_proposals:
    st.caption("Full proposal history across all statuses.")
    proposals_df = load_table("proposals", limit=300)

    if proposals_df.empty:
        st.info("No proposals yet.")
    else:
        status_filter = st.multiselect(
            "Filter by status",
            options=sorted(proposals_df["status"].dropna().unique()),
            default=[],
        )
        verdict_filter = st.multiselect(
            "Filter by Critic verdict",
            options=sorted(proposals_df["critic_verdict"].dropna().unique()),
            default=[],
        )

        filtered = proposals_df
        if status_filter:
            filtered = filtered[filtered["status"].isin(status_filter)]
        if verdict_filter:
            filtered = filtered[filtered["critic_verdict"].isin(verdict_filter)]

        display_cols = [
            "created_at", "symbol", "strategy_type", "timeframe", "status",
            "critic_verdict", "critic_risk_score", "proposer_confidence",
        ]
        display_cols = [c for c in display_cols if c in filtered.columns]
        st.dataframe(filtered[display_cols], use_container_width=True, height=500)


# ---------------------------------------------------------------------
# Tab 3: Wishlist
# ---------------------------------------------------------------------

with tab_wishlist:
    st.caption("Proposals saved for later — includes a signal snapshot for staleness checks.")
    wishlist_df = load_table("wishlist", limit=200)

    if wishlist_df.empty:
        st.info("Wishlist is empty.")
    else:
        active_only = st.checkbox("Show active only", value=True)
        display_df = wishlist_df
        if active_only and "status" in display_df.columns:
            display_df = display_df[display_df["status"] == "active"]

        display_cols = [
            "created_at", "symbol", "status", "is_stale",
            "snapshot_taken_at", "notes",
        ]
        display_cols = [c for c in display_cols if c in display_df.columns]
        st.dataframe(display_df[display_cols], use_container_width=True, height=500)


# ---------------------------------------------------------------------
# Tab 4: Trades (the P&L view — this is what judges will care about most)
# ---------------------------------------------------------------------

with tab_trades:
    st.caption("Executed orders. realized_pnl populates once positions are closed.")
    trades_df = load_table("trades", limit=300)

    if trades_df.empty:
        st.info("No trades executed yet.")
    else:
        m1, m2, m3 = st.columns(3)
        m1.metric("Total trades", len(trades_df))
        filled = trades_df[trades_df["status"].isin(["filled", "closed"])]
        m2.metric("Filled/closed", len(filled))
        if "realized_pnl" in trades_df.columns:
            total_pnl = trades_df["realized_pnl"].dropna().sum()
            m3.metric("Total realized P&L", f"${total_pnl:,.2f}")

        display_cols = [
            "created_at", "symbol", "side", "quantity", "status",
            "fill_price", "realized_pnl", "alpaca_order_id",
        ]
        display_cols = [c for c in display_cols if c in trades_df.columns]
        st.dataframe(trades_df[display_cols], use_container_width=True, height=500)


# ---------------------------------------------------------------------
# Tab 5: Circuit breaker audit log
# ---------------------------------------------------------------------

with tab_breaker_log:
    st.caption("Full audit trail of every pre_scan / pre_execution / manual check.")
    breaker_df = load_table("circuit_breaker_events", limit=200)

    if breaker_df.empty:
        st.info("No circuit breaker events logged yet.")
    else:
        display_cols = [
            "created_at", "check_point", "tripped", "reasons",
            "equity", "daily_pnl_pct", "open_positions_count",
            "trades_today_count", "cleared_by_human",
        ]
        display_cols = [c for c in display_cols if c in breaker_df.columns]
        st.dataframe(breaker_df[display_cols], use_container_width=True, height=500)


st.divider()
st.caption(f"Refreshed at {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')} · Data cached 15s")
if st.button("🔄 Force refresh"):
    refresh_all()
