"""
Account-level circuit breaker.

Design intent (from planning):
- Checked at TWO points: before the autonomous scan loop runs, and again
  immediately before any execution (manual-approved or auto).
- "Sticky pause": once tripped, stays tripped until a human clears it -
  it does NOT auto-resume after cooldown_minutes_after_trip elapses.
  That field is informational/for the dashboard countdown display only.
- Every trip and every check is logged to `circuit_breaker_events` in
  Supabase, so the dashboard can show a full audit trail.

This module is intentionally dependency-light (no Alpaca/Supabase client
construction happens at import time) so it can be unit tested with fake
account snapshots.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum

from config.settings import CircuitBreakerConfig, settings


class TripReason(str, Enum):
    DAILY_LOSS_PCT = "daily_loss_pct_exceeded"
    DAILY_LOSS_ABSOLUTE = "daily_loss_absolute_exceeded"
    MAX_OPEN_POSITIONS = "max_open_positions_exceeded"
    MAX_TRADES_PER_DAY = "max_trades_per_day_exceeded"
    MIN_EQUITY_FLOOR = "min_equity_floor_breached"
    MANUAL_HALT = "manual_halt"  # human-triggered kill switch


@dataclass
class AccountSnapshot:
    """Minimal set of account facts needed to evaluate the breaker.
    Populated from Alpaca's /account and /positions/orders endpoints,
    or from Supabase's local trade log for today's count."""
    equity: float
    last_equity: float  # previous trading day's closing equity, from Alpaca
    open_positions_count: int
    trades_today_count: int
    manual_halt_active: bool = False

    @property
    def daily_pnl_pct(self) -> float:
        if self.last_equity == 0:
            return 0.0
        return ((self.equity - self.last_equity) / self.last_equity) * 100

    @property
    def daily_pnl_absolute(self) -> float:
        return self.equity - self.last_equity


@dataclass
class BreakerResult:
    tripped: bool
    reasons: list[TripReason]
    checked_at: datetime
    snapshot: AccountSnapshot

    @property
    def is_safe_to_proceed(self) -> bool:
        return not self.tripped


def evaluate(
    snapshot: AccountSnapshot,
    config: CircuitBreakerConfig | None = None,
) -> BreakerResult:
    """Pure function: given an account snapshot, decide whether the
    circuit breaker should be tripped. No I/O here - callers are
    responsible for fetching the snapshot and logging the result."""
    cfg = config or settings.circuit_breaker
    reasons: list[TripReason] = []

    if snapshot.manual_halt_active:
        reasons.append(TripReason.MANUAL_HALT)

    if snapshot.daily_pnl_pct <= -abs(cfg.max_daily_loss_pct):
        reasons.append(TripReason.DAILY_LOSS_PCT)

    if cfg.max_daily_loss_absolute is not None:
        if snapshot.daily_pnl_absolute <= -abs(cfg.max_daily_loss_absolute):
            reasons.append(TripReason.DAILY_LOSS_ABSOLUTE)

    if snapshot.open_positions_count >= cfg.max_open_positions:
        reasons.append(TripReason.MAX_OPEN_POSITIONS)

    if snapshot.trades_today_count >= cfg.max_trades_per_day:
        reasons.append(TripReason.MAX_TRADES_PER_DAY)

    if cfg.min_account_equity > 0 and snapshot.equity < cfg.min_account_equity:
        reasons.append(TripReason.MIN_EQUITY_FLOOR)

    return BreakerResult(
        tripped=len(reasons) > 0,
        reasons=reasons,
        checked_at=datetime.now(timezone.utc),
        snapshot=snapshot,
    )


# --- Wiring points (to implement once Alpaca/Supabase clients exist) ---

def check_pre_scan() -> BreakerResult:
    """Call this before the autonomous scan/propose loop starts.
    TODO (Day 3): fetch live AccountSnapshot from Alpaca + Supabase,
    call evaluate(), persist result to circuit_breaker_events, and if
    tripped, the scan loop should skip its run entirely."""
    raise NotImplementedError("Wire up once Alpaca client is in core/alpaca_client.py")


def check_pre_execution() -> BreakerResult:
    """Call this immediately before ANY order submission - manual or
    auto. This is the last line of defense even if check_pre_scan
    passed earlier (state may have changed since then)."""
    raise NotImplementedError("Wire up once Alpaca client is in core/alpaca_client.py")


if __name__ == "__main__":
    # Manual smoke test with a fake snapshot: `python -m core.circuit_breaker`
    fake = AccountSnapshot(
        equity=97000,
        last_equity=100000,
        open_positions_count=3,
        trades_today_count=5,
    )
    result = evaluate(fake)
    print(f"Tripped: {result.tripped}")
    print(f"Reasons: {[r.value for r in result.reasons]}")
    print(f"Daily P&L: {fake.daily_pnl_pct:.2f}%")
